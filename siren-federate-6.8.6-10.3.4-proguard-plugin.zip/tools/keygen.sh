#!/bin/bash
JAVA_BIN="java"
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

if [ -n "$JAVA_HOME" ]; then
  JAVA_BIN="$JAVA_HOME/bin/java"
fi

"$JAVA_BIN" -cp "$DIR/../*" io.siren.federate.tools.KeyGen "$@"
